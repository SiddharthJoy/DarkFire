package com.example.darkfire;

public class User {
    public String EM,NM,PASS;

    public User(){

    }

    public User(String NM,String EM,String PASS){
        this.NM = NM;
        this.EM = EM;
        this.PASS = PASS;
    }
}
